#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


size_t my_strlen(const char* s);
char *my_strstr(const char *s1, const char *s2);

#endif // FUNCIONES_H_INCLUDED
