#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "examen.h"
typedef struct
{
    char palabra[64];
    int cantLetras;
} tPalabra;
int crearLotePruebaTxtFrasesSimMIO(const char* nomArch)
{

    FILE *pf;
    char texto1[512] = "Estudio Ingenieria en Informatica en la Universidad Nacional De La Matanza, la carrera esta orientada a programar.\nMi materia favorita es Topicos de programacion y Arquitectura de Computadoras.\nUn desarrollador tiene que tener caracteristicas especificas como creatividad y resolutividad.\n";

    pf = fopen(nomArch,"wt");
    if(!pf)
    {
        puts("\nError al crear el archivo de pruebas");
        exit(1);
    }

    fwrite(texto1,512,1,pf);

    fclose(pf);
    return 1;
}
void llenar_con_0(char *cad)
{


}

int compPal(const void*a,const void* b)
{
    t_palabra* arg1 = (t_palabra*)a;
    t_palabra* arg2 = (t_palabra*)b;

    return (arg1->cant_letras - arg2->cant_letras);
}

int insertar_en_vec_ordenado(void* vec, void* elem,int *ce,int capacidad,int tam,int cmp(const void*,const void*))
{
    void* ini = vec;
    void* fin = vec + (tam*(*ce));
    int lleno = 0;

    if(*ce == capacidad)
        lleno = 1;

    while(ini <= fin && cmp(elem,vec)<0)
        ini+=tam;

    if((ini <= fin && !lleno) || !(cmp(elem,vec)<0))
    {
        memmove(ini+tam,ini,fin-(tam*lleno)-ini+tam);
        memcpy(ini,elem,tam);

        if(!lleno)
            *ce+=1;
        return 1;
    }

    return 0;
}


int palabrasMasLargasMIO(const char* archEntrada, const char* archSalida)
{
    t_palabra vector[15];
    t_palabra *vec = vector;
    int ce = 0;

    char linea[1024];
    char* letra_act;


    FILE* pEntrada,*pSalida;

    t_palabra aux_pal;



    ///---------------------------------------------------------------///
    pEntrada = fopen(archEntrada,"rt");
    pSalida = fopen (archSalida,"wt");

    if(!pEntrada || !pSalida)
    {
        puts("\0Error al crear algun archivo...");
        exit(-1);
    }



    while(fgets(linea,1024,pEntrada)!= NULL) ///leo cada frase
    {
        letra_act = linea;
        while(*letra_act != '\0') ///hasta que termine cada linea
        {

            while(!isalpha(*letra_act)) ///borro espacios innecesarios
                letra_act++;

            aux_pal.cant_letras = 0;

            while(isalpha(*letra_act))
            {
                aux_pal.cant_letras +=1;
                letra_act++;
            }

            strncpy(aux_pal.palabra,letra_act-aux_pal.cant_letras,aux_pal.cant_letras);

            insertar_en_vec_ordenado(vec,&aux_pal,&ce,15,sizeof(t_palabra),compPal);


        }


    }



    return 1;
}
