#ifndef EXAMEN_H_INCLUDED
#define EXAMEN_H_INCLUDED

typedef struct
{
    char palabra[100];
    int cant_letras;
}t_palabra;


int crearLotePruebaTxtFrasesSim(const char* nomArch);
int palabrasMasLargas(const char* archEntrada, const char* archSalida);



int crearLotePruebaTxtFrasesSimMIO(const char* nomArch);
int palabrasMasLargasMIO(const char* archEntrada, const char* archSalida);

#endif // EXAMEN_H_INCLUDED
