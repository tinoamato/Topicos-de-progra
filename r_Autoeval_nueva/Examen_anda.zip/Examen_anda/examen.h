#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef EXAMEN_H_INCLUDED
#define EXAMEN_H_INCLUDED
#define TAM 1024
typedef struct {
                char contenido[TAM];
                int ce;
                } tFrase;
char* obtenerFrase(char* frase);
size_t mStrlen(const char* cadena);
void llenarVecStruct(tFrase* frases);
void mostrarFrasesYCe(tFrase* frases,int ce);
char* mStrcpy(char* copia, const char* original);
void comparoFrases(tFrase* frases);




#endif // EXAMEN_H_INCLUDED
