#include "examen.h"
size_t mStrlen(const char* cadena)
{
    int ce=0;
    while(*cadena!='\0')
    {
        ce++;
        cadena++;
    }
    return ce;
}
void llenarVecStruct(tFrase* frases) //Asumo que las primeras 5 son las mayores frases para luego ir comparando una por una
{
    int contF=0;//inicializo un contador de frases
    char cad[TAM];
    while(contF<5 && obtenerFrase(cad)!=NULL) //Cargo 5 frases o las que haya en realidad
    {
        mStrcpy(frases->contenido,cad);
        frases->ce=mStrlen(frases->contenido);
        frases++;
        contF++;
    }
}
void comparoFrases(tFrase* frases)
{
    char cad[TAM];
    tFrase* inicio = frases;
    int contCF=0; //Lo voy a usar para saber si tengo que cambiar la frase o no
    while(obtenerFrase(cad)!=NULL)
    {
        while(strlen(cad)<=frases->ce && contCF!=5)
        {
            contCF++; //Cuento la cantidad de frases revisadas, ya que asumo que el maximo a revisar son 5
            frases++;
        }
        contCF=0;
        if(contCF!=5)
        {
            mStrcpy(frases->contenido,cad);
            frases->ce=strlen(cad);
        }
        frases = inicio;
    }
}
void mostrarFrasesYCe(tFrase* frases, int ce)
{
    int i;
    for(i=0;i<ce;i++)
    {
        printf("%s",frases->contenido);
        printf("%d\n",frases->ce);
        frases++;
    }
}
char* mStrcpy(char* copia, const char* original)
{
    char* inicio = copia;
    while(*original!='\0')
    {
        *copia = *original;
        copia++;
        original++;
    }
    *copia = '\0';
    return inicio;
}
